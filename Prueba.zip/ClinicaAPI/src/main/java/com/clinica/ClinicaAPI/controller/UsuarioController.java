package com.clinica.ClinicaAPI.controller;

import org.springframework.web.bind.annotation.*;
import com.clinica.ClinicaAPI.service.UsuarioService;
import java.util.Map;

@RestController
@RequestMapping("/api")
public class UsuarioController {

    private final UsuarioService usuarioService;

    public UsuarioController(UsuarioService usuarioService) {
        this.usuarioService = usuarioService;
    }

    @PostMapping("/login")
    public String login(@RequestBody Map<String, String> credenciales) {
        String usuario = credenciales.get("usuario");
        String contrasena = credenciales.get("contrasena");
        return usuarioService.iniciarSesion(usuario, contrasena);
    }
}
