package com.clinica.ClinicaAPI.service;

import org.springframework.stereotype.Service;
import com.clinica.ClinicaAPI.model.Usuario;

@Service
public class UsuarioService {

    private final Usuario usuarioEjemplo = new Usuario("Sofía", "sofia123", "1234");

    public String iniciarSesion(String usuario, String contrasena) {
        if (usuarioEjemplo.validarAcceso(usuario, contrasena)) {
            return "Acceso concedido. Bienvenida, " + usuarioEjemplo.getNombre();
        } else {
            return "Acceso denegado. Usuario o contraseña incorrectos.";
        }
    }
}
