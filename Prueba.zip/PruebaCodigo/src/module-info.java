/**
 * 
 */
/**
 * @author Redes-20
 *
 */
module PruebaCodigo {
}