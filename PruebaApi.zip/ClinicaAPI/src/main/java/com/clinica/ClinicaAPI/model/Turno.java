package com.clinica.ClinicaAPI.model;

import jakarta.persistence.*;
import java.util.Date;

@Entity
@Table(name = "turnos")
public class Turno {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Temporal(TemporalType.DATE)
    private Date fecha;

    private String hora;
    private String estado;

    // Relación con el paciente
    @ManyToOne
    @JoinColumn(name = "paciente_id")
    private Paciente paciente;

    // Relación con el médico
    @ManyToOne
    @JoinColumn(name = "medico_id")
    private Medico medico;

    public Turno() {} 

    public Turno(Date fecha, String hora, String estado, Paciente paciente, Medico medico) {
        this.fecha = fecha;
        this.hora = hora;
        this.estado = estado;
        this.paciente = paciente;
        this.medico = medico;
    }

    public void confirmar() {
        this.estado = "Confirmado";
        System.out.println("Turno confirmado para el " + fecha);
    }

    public void cancelar() {
        this.estado = "Cancelado";
        System.out.println("Turno cancelado para el " + fecha);
    }

    // Getters y setters
    public Long getId() {
        return id;
    }

    public Date getFecha() {
        return fecha;
    }

    public String getHora() {
        return hora;
    }

    public String getEstado() {
        return estado;
    }

    public Paciente getPaciente() {
        return paciente;
    }

    public Medico getMedico() {
        return medico;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public void setFecha(Date fecha) {
        this.fecha = fecha;
    }

    public void setHora(String hora) {
        this.hora = hora;
    }

    public void setPaciente(Paciente paciente) {
        this.paciente = paciente;
    }

    public void setMedico(Medico medico) {
        this.medico = medico;
    }

    @Override
    public String toString() {
        return "\nTurno del " + fecha + " a las " + hora +
               " con el Dr. " + medico.getNombre() +
               " para el paciente " + paciente.getNombre() +
               " | Estado: " + estado;
    }
}
