package com.clinica.ClinicaAPI.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.web.bind.annotation.*;
import com.clinica.ClinicaAPI.model.Usuario;
import com.clinica.ClinicaAPI.service.UsuarioService;

@RestController
@RequestMapping("/api/usuarios")
public class TurnoController {

    private final UsuarioService service;

    public TurnoController(UsuarioService service) {
        this.service = service;
    }

    @GetMapping
    public List<Usuario> listar() {
        return service.listar();
    }

    @GetMapping("/{id}")
    public Optional<Usuario> obtener(@PathVariable Long id) {
        return service.buscarPorId(id);
    }

    @PostMapping
    public Usuario crear(@RequestBody Usuario u) {
        return service.guardar(u);
    }

    @DeleteMapping("/{id}")
    public void eliminar(@PathVariable Long id) {
        service.eliminar(id);
    }
}

