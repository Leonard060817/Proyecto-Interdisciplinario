package com.clinica.ClinicaAPI.model;

import jakarta.persistence.*;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "historias_clinicas")
public class HistoriaClinica {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @OneToMany(mappedBy = "historiaClinica", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<Diagnostico> diagnosticos = new ArrayList<>();

    public HistoriaClinica() {
    }

    public void agregarDiagnostico(Diagnostico d) {
        diagnosticos.add(d);
        d.setHistoriaClinica(this); 
    }

    public void mostrar() {
        if (diagnosticos.isEmpty()) {
            System.out.println("No hay diagnósticos registrados.");
        } else {
            for (Diagnostico d : diagnosticos) {
                System.out.println(d);
            }
        }
    }

    // Getters y setters
    public Long getId() {
        return id;
    }

    public List<Diagnostico> getDiagnosticos() {
        return diagnosticos;
    }

    public void setDiagnosticos(List<Diagnostico> diagnosticos) {
        this.diagnosticos = diagnosticos;
    }
}
