package com.clinica.ClinicaAPI.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.web.bind.annotation.*;
import com.clinica.ClinicaAPI.model.Paciente;
import com.clinica.ClinicaAPI.service.PacienteService;

@RestController
@RequestMapping("/api/pacientes")
public class PacienteController {

    private final PacienteService service;

    public PacienteController(PacienteService service) {
        this.service = service;
    }

    @GetMapping
    public List<Paciente> listar() {
        return service.listar();
    }

    @GetMapping("/{id}")
    public Optional<Paciente> obtener(@PathVariable Long id) {
        return service.buscarPorId(id);
    }

    @PostMapping
    public Paciente crear(@RequestBody Paciente p) {
        return service.guardar(p);
    }

    @PutMapping("/{id}")
    public Paciente actualizar(@PathVariable Long id, @RequestBody Paciente p) {
        p.setId(id);
        return service.guardar(p);
    }

    @DeleteMapping("/{id}")
    public void eliminar(@PathVariable Long id) {
        service.eliminar(id);
    }
}
