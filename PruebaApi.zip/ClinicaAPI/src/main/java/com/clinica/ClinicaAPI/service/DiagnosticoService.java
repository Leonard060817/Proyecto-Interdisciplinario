package com.clinica.ClinicaAPI.service;

import java.util.List;
import java.util.Optional;
import org.springframework.stereotype.Service;
import com.clinica.ClinicaAPI.model.Diagnostico;
import com.clinica.ClinicaAPI.repository.DiagnosticoRepository;

@Service
public class DiagnosticoService {
    private final DiagnosticoRepository repo;

    public DiagnosticoService(DiagnosticoRepository repo) {
        this.repo = repo;
    }

    public List<Diagnostico> listar() {
        return repo.findAll();
    }

    public Optional<Diagnostico> buscarPorId(Long id) {
        return repo.findById(id);
    }

    public Diagnostico guardar(Diagnostico d) {
        return repo.save(d);
    }

    public void eliminar(Long id) {
        repo.deleteById(id);
    }
}
