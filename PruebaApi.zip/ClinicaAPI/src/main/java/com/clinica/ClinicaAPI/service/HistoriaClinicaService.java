package com.clinica.ClinicaAPI.service;

import java.util.List;
import java.util.Optional;
import org.springframework.stereotype.Service;
import com.clinica.ClinicaAPI.model.HistoriaClinica;
import com.clinica.ClinicaAPI.repository.HistoriaClinicaRepository;

@Service
public class HistoriaClinicaService {
    private final HistoriaClinicaRepository repo;

    public HistoriaClinicaService(HistoriaClinicaRepository repo) {
        this.repo = repo;
    }

    public List<HistoriaClinica> listar() {
        return repo.findAll();
    }

    public Optional<HistoriaClinica> buscarPorId(Long id) {
        return repo.findById(id);
    }

    public HistoriaClinica guardar(HistoriaClinica h) {
        return repo.save(h);
    }

    public void eliminar(Long id) {
        repo.deleteById(id);
    }
}
