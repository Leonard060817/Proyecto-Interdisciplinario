package com.clinica.ClinicaAPI.model;

public class Usuario {

    private String nombre;
    private String usuario;
    private String contrasena;

    public Usuario(String nombre, String usuario, String contrasena) {
        this.nombre = nombre;
        this.usuario = usuario;
        this.contrasena = contrasena;
    }

    public boolean validarAcceso(String usuarioIngresado, String contrasenaIngresada) {
        return this.usuario.equals(usuarioIngresado) && this.contrasena.equals(contrasenaIngresada);
    }

    public String getNombre() { return nombre; }
    public String getUsuario() { return usuario; }
}
