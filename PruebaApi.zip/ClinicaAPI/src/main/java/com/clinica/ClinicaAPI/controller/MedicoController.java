package com.clinica.ClinicaAPI.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.web.bind.annotation.*;
import com.clinica.ClinicaAPI.model.Medico;
import com.clinica.ClinicaAPI.service.MedicoService;

@RestController
@RequestMapping("/api/medicos")
public class MedicoController {

    private final MedicoService service;

    public MedicoController(MedicoService service) {
        this.service = service;
    }

    @GetMapping
    public List<Medico> listar() {
        return service.listar();
    }

    @GetMapping("/{id}")
    public Optional<Medico> obtener(@PathVariable Long id) {
        return service.buscarPorId(id);
    }

    @PostMapping
    public Medico crear(@RequestBody Medico m) {
        return service.guardar(m);
    }

    @PutMapping("/{id}")
    public Medico actualizar(@PathVariable Long id, @RequestBody Medico m) {
        m.setId(id);
        return service.guardar(m);
    }

    @DeleteMapping("/{id}")
    public void eliminar(@PathVariable Long id) {
        service.eliminar(id);
    }
}
