package com.clinica.ClinicaAPI.service;

import java.util.List;
import java.util.Optional;
import org.springframework.stereotype.Service;
import com.clinica.ClinicaAPI.model.Medico;
import com.clinica.ClinicaAPI.repository.MedicoRepository;

@Service
public class MedicoService {
    private final MedicoRepository repo;

    public MedicoService(MedicoRepository repo) {
        this.repo = repo;
    }

    public List<Medico> listar() {
        return repo.findAll();
    }

    public Optional<Medico> buscarPorId(Long id) {
        return repo.findById(id);
    }

    public Medico guardar(Medico m) {
        return repo.save(m);
    }

    public void eliminar(Long id) {
        repo.deleteById(id);
    }
}
