package pruebaCodigo;

import jakarta.persistence.*;
import java.util.Date;

@Entity
@Table(name = "diagnosticos")
public class Diagnostico {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Temporal(TemporalType.TIMESTAMP)
    private Date fecha;

    private String texto;

    // Relación con el médico que hizo el diagnóstico
    @ManyToOne
    @JoinColumn(name = "medico_id")
    private Medico medico;

    // Relación con la historia clínica a la que pertenece
    @ManyToOne
    @JoinColumn(name = "historia_id")
    private HistoriaClinica historiaClinica;

    public Diagnostico() {
        this.fecha = new Date(); // Por defecto, la fecha actual
    }

    public Diagnostico(String texto, Medico medico) {
        this.fecha = new Date();
        this.texto = texto;
        this.medico = medico;
    }

    @Override
    public String toString() {
        return "Fecha: " + fecha + "\nMédico: " + medico.getNombre() + "\nDiagnóstico: " + texto + "\n";
    }

    // Getters y setters
    public Long getId() {
        return id;
    }

    public Date getFecha() {
        return fecha;
    }

    public String getTexto() {
        return texto;
    }

    public Medico getMedico() {
        return medico;
    }

    public HistoriaClinica getHistoriaClinica() {
        return historiaClinica;
    }

    public void setHistoriaClinica(HistoriaClinica historiaClinica) {
        this.historiaClinica = historiaClinica;
    }

    public void setTexto(String texto) {
        this.texto = texto;
    }

    public void setMedico(Medico medico) {
        this.medico = medico;
    }
}
