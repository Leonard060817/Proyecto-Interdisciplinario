package com.example.ClinicaApis.repository;

import com.example.ClinicaApis.model.Diagnostico;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@Repository
public interface DiagnosticoRepository extends JpaRepository<Diagnostico, Long> {

    List<Diagnostico> findByDescripcionContainingIgnoreCase(String descripcion);

    List<Diagnostico> findByPacienteId(Long pacienteId);

    List<Diagnostico> findByFecha(LocalDate fecha);

    Optional<Diagnostico> findTopByPacienteIdOrderByFechaDesc(Long pacienteId);
}
