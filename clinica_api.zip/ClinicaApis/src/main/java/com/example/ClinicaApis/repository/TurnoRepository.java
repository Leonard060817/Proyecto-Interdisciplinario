package com.example.ClinicaApis.repository;

import com.example.ClinicaApis.model.Turno;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@Repository
public interface TurnoRepository extends JpaRepository<Turno, Long> {

    List<Turno> findByPacienteId(Long pacienteId);

    List<Turno> findByMedicoId(Long medicoId);

    List<Turno> findByFecha(LocalDate fecha);

    Optional<Turno> findTopByPacienteIdOrderByFechaAsc(Long pacienteId);

    Optional<Turno> findTopByMedicoIdOrderByFechaAsc(Long medicoId);
}
