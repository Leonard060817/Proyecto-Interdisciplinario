package com.example.ClinicaApis.controller;

import com.example.ClinicaApis.model.Diagnostico;
import com.example.ClinicaApis.service.DiagnosticoService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/diagnosticos")
public class TurnoController {

    private final DiagnosticoService service;

    public TurnoController(DiagnosticoService service) {
        this.service = service;
    }


    @GetMapping
    public ResponseEntity<List<Diagnostico>> listar() {
        return ResponseEntity.ok(service.listar());
    }


    @PostMapping
    public ResponseEntity<Diagnostico> guardar(@RequestBody Diagnostico diagnostico) {
        Diagnostico nuevo = service.guardar(diagnostico);
        return ResponseEntity.status(201).body(nuevo);
    }


    @GetMapping("/{id}")
    public ResponseEntity<Diagnostico> obtener(@PathVariable Long id) {
        Optional<Diagnostico> diagnostico = service.buscar(id);
        return diagnostico.map(ResponseEntity::ok)
                          .orElse(ResponseEntity.notFound().build());
    }


    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminar(@PathVariable Long id) {
        boolean eliminado = service.eliminar(id);
        if (eliminado) {
            return ResponseEntity.noContent().build();
        }
        return ResponseEntity.notFound().build();
    }
}
