package com.example.ClinicaApis.controller;

import com.example.ClinicaApis.model.HistoriaClinica;
import com.example.ClinicaApis.service.HistoriaClinicaService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/historias")
public class HistoriaClinicaController {

    private final HistoriaClinicaService service;

    public HistoriaClinicaController(HistoriaClinicaService service) {
        this.service = service;
    }


    @GetMapping
    public ResponseEntity<List<HistoriaClinica>> listar() {
        return ResponseEntity.ok(service.listar());
    }


    @PostMapping
    public ResponseEntity<HistoriaClinica> guardar(@RequestBody HistoriaClinica historiaClinica) {
        HistoriaClinica nueva = service.guardar(historiaClinica);
        return ResponseEntity.status(201).body(nueva);
    }


    @GetMapping("/{id}")
    public ResponseEntity<HistoriaClinica> obtener(@PathVariable Long id) {
        Optional<HistoriaClinica> historia = service.buscar(id);
        return historia.map(ResponseEntity::ok)
                       .orElse(ResponseEntity.notFound().build());
    }


    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminar(@PathVariable Long id) {
        boolean eliminado = service.eliminar(id);
        if (eliminado) {
            return ResponseEntity.noContent().build();
        }
        return ResponseEntity.notFound().build();
    }
}
