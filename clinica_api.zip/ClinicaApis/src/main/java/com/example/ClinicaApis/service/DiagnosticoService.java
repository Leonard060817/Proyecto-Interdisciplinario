package com.example.ClinicaApis.service;

import com.example.ClinicaApis.model.Diagnostico;
import com.example.ClinicaApis.repository.DiagnosticoRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class DiagnosticoService {

    private final DiagnosticoRepository DiagnosticoRepository;

    public DiagnosticoService(DiagnosticoRepository DiagnosticoRepository) {
        this.DiagnosticoRepository = DiagnosticoRepository;
    }

    
    public List<Diagnostico> listar() {
        return DiagnosticoRepository.findAll();
    }


    public Diagnostico guardar(Diagnostico diagnostico) {
        return DiagnosticoRepository.save(diagnostico);
    }


    public Optional<Diagnostico> buscar(Long id) {
        return DiagnosticoRepository.findById(id);
    }


    public boolean eliminar(Long id) {
        if (DiagnosticoRepository.existsById(id)) {
            DiagnosticoRepository.deleteById(id);
            return true;
        }
        return false;
    }
}
