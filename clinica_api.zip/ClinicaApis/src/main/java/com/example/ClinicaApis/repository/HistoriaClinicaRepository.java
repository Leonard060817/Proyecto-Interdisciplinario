package com.example.ClinicaApis.repository;

import com.example.ClinicaApis.model.HistoriaClinica;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@Repository
public interface HistoriaClinicaRepository extends JpaRepository<HistoriaClinica, Long> {

    List<HistoriaClinica> findByPacienteId(Long pacienteId);

    List<HistoriaClinica> findByDiagnosticoContainingIgnoreCase(String diagnostico);

    List<HistoriaClinica> findByFecha(LocalDate fecha);

    Optional<HistoriaClinica> findTopByPacienteIdOrderByFechaDesc(Long pacienteId);
}
