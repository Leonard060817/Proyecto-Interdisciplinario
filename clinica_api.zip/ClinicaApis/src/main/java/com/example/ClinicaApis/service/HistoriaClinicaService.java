package com.example.ClinicaApis.service;

import com.example.ClinicaApis.model.HistoriaClinica;
import com.example.ClinicaApis.repository.HistoriaClinicaRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class HistoriaClinicaService {

    private final HistoriaClinicaRepository HistoriaClinicaRepository;

    public HistoriaClinicaService(HistoriaClinicaRepository HistoriaClinicaRepository) {
        this.HistoriaClinicaRepository = HistoriaClinicaRepository;
    }


    public List<HistoriaClinica> listar() {
        return HistoriaClinicaRepository.findAll();
    }


    public HistoriaClinica guardar(HistoriaClinica historiaClinica) {
        return HistoriaClinicaRepository.save(historiaClinica);
    }


    public Optional<HistoriaClinica> buscar(Long id) {
        return HistoriaClinicaRepository.findById(id);
    }


    public boolean eliminar(Long id) {
        if (HistoriaClinicaRepository.existsById(id)) {
            HistoriaClinicaRepository.deleteById(id);
            return true;
        }
        return false;
    }
}
