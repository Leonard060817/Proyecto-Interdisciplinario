package com.example.ClinicaApis.controller;

import com.example.ClinicaApis.model.Medico;
import com.example.ClinicaApis.service.MedicoService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/medicos")
public class MedicoController {

    private final MedicoService service;

    public MedicoController(MedicoService service) {
        this.service = service;
    }


    @GetMapping
    public ResponseEntity<List<Medico>> listar() {
        return ResponseEntity.ok(service.listar());
    }


    @PostMapping
    public ResponseEntity<Medico> guardar(@RequestBody Medico medico) {
        Medico nuevo = service.guardar(medico);
        return ResponseEntity.status(201).body(nuevo);
    }


    @GetMapping("/{id}")
    public ResponseEntity<Medico> obtener(@PathVariable Long id) {
        Optional<Medico> medico = service.buscar(id);
        return medico.map(ResponseEntity::ok)
                     .orElse(ResponseEntity.notFound().build());
    }


    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminar(@PathVariable Long id) {
        boolean eliminado = service.eliminar(id);
        if (eliminado) {
            return ResponseEntity.noContent().build();
        }
        return ResponseEntity.notFound().build();
    }
}

