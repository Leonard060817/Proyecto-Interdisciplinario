package com.example.ClinicaApis.model;

import jakarta.persistence.*;
import java.time.LocalDate;

@Entity
@Table(name = "diagnosticos")
public class Diagnostico {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private LocalDate fecha;
    private String texto;

    @ManyToOne
    @JoinColumn(name = "medico_id")
    private Medico medico;

    @ManyToOne
    @JoinColumn(name = "historia_id")
    private HistoriaClinica historiaClinica;

    public Diagnostico() {}

    public Diagnostico(String texto, Medico medico, HistoriaClinica historia) {
        this.fecha = LocalDate.now();
        this.texto = texto;
        this.medico = medico;
        this.historiaClinica = historia;
    }

    public Long getId() { return id; }

    public LocalDate getFecha() { return fecha; }
    public void setFecha(LocalDate fecha) { this.fecha = fecha; }

    public String getTexto() { return texto; }
    public void setTexto(String texto) { this.texto = texto; }

    public Medico getMedico() { return medico; }
    public void setMedico(Medico medico) { this.medico = medico; }

    public HistoriaClinica getHistoriaClinica() { return historiaClinica; }
    public void setHistoriaClinica(HistoriaClinica historiaClinica) { this.historiaClinica = historiaClinica; }

    @Override
    public String toString() {
        return "Diagnostico{" +
                "id=" + id +
                ", fecha=" + fecha +
                ", texto='" + texto + '\'' +
                ", medico=" + (medico != null ? medico.getNombre() : "null") +
                '}';
    }
}
