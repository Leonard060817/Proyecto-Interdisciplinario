package com.example.ClinicaApis.service;

import org.springframework.stereotype.Service;

import com.example.ClinicaApis.model.Paciente;
import com.example.ClinicaApis.repository.PacienteRepository;

import java.util.List;
import java.util.Optional;
@Service
public class PacienteService {

    private final PacienteRepository PacienteRepository;

    public PacienteService(PacienteRepository pacienteRepository) {
        this.PacienteRepository = pacienteRepository;
    }


    public List<Paciente> listar() {
        return PacienteRepository.findAll();
    }


    public Paciente guardar(Paciente paciente) {
        return PacienteRepository.save(paciente);
    }


    public Optional<Paciente> buscar(Long id) {
        return PacienteRepository.findById(id);
    }


    public boolean eliminar(Long id) {
        if (PacienteRepository.existsById(id)) {
            PacienteRepository.deleteById(id);
            return true;
        }
        return false;
    }
}
