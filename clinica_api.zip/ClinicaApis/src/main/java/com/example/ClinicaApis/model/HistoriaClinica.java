package com.example.ClinicaApis.model;

import jakarta.persistence.*;
import java.util.*;

@Entity
@Table(name = "historias_clinicas")
public class HistoriaClinica {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @OneToOne
    @JoinColumn(name = "paciente_id")
    private Paciente paciente;

    @OneToMany(mappedBy = "historiaClinica", cascade = CascadeType.ALL)
    private List<Diagnostico> diagnosticos = new ArrayList<>();

    public HistoriaClinica() {}

    public Long getId() { return id; }

    public Paciente getPaciente() { return paciente; }
    public void setPaciente(Paciente paciente) { this.paciente = paciente; }

    public List<Diagnostico> getDiagnosticos() { return diagnosticos; }
    public void setDiagnosticos(List<Diagnostico> diagnosticos) { this.diagnosticos = diagnosticos; }

    @Override
    public String toString() {
        return "HistoriaClinica{" +
                "id=" + id +
                ", paciente=" + (paciente != null ? paciente.getNombre() : "null") +
                ", diagnosticos=" + diagnosticos.size() +
                '}';
    }
}
