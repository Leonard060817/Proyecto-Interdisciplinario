package com.example.ClinicaApis.service;

import com.example.ClinicaApis.model.Turno;
import com.example.ClinicaApis	.repository.TurnoRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class TurnoService {

    private final TurnoRepository TurnoRepository;

    public TurnoService(TurnoRepository turnoRepository) {
        this.TurnoRepository = turnoRepository;
    }


    public List<Turno> listar() {
        return TurnoRepository.findAll();
    }


    public Turno guardar(Turno turno) {
        return TurnoRepository.save(turno);
    }


    public Optional<Turno> buscar(Long id) {
        return TurnoRepository.findById(id);
    }


    public boolean eliminar(Long id) {
        if (TurnoRepository.existsById(id)) {
            TurnoRepository.deleteById(id);
            return true;
        }
        return false;
    }
}
