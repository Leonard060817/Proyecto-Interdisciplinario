package com.example.ClinicaApis.repository;

import com.example.ClinicaApis.model.Medico;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface MedicoRepository extends JpaRepository<Medico, Long> {

    List<Medico> findByEspecialidadContainingIgnoreCase(String especialidad);

    Optional<Medico> findByMatricula(String matricula);

    Optional<Medico> findByEmail(String email);
}
