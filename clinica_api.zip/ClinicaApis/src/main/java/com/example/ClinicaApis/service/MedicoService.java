package com.example.ClinicaApis.service;

import com.example.ClinicaApis.model.Medico;
import com.example.ClinicaApis.repository.MedicoRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class MedicoService {

    private final MedicoRepository MedicoRepository;

    public MedicoService(MedicoRepository medicoRepository) {
        this.MedicoRepository = medicoRepository;
    }


    public List<Medico> listar() {
        return MedicoRepository.findAll();
    }


    public Medico guardar(Medico medico) {
        return MedicoRepository.save(medico);
    }


    public Optional<Medico> buscar(Long id) {
        return MedicoRepository.findById(id);
    }


    public boolean eliminar(Long id) {
        if (MedicoRepository.existsById(id)) {
            MedicoRepository.deleteById(id);
            return true;
        }
        return false;
    }
}
