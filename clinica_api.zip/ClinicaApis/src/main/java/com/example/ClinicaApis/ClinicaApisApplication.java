package com.example.ClinicaApis;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ClinicaApisApplication {

	public static void main(String[] args) {
		SpringApplication.run(ClinicaApisApplication.class, args);
	}

}
