package com.example.ClinicaApis.model;

import jakarta.persistence.*;
import java.util.*;

@Entity
@Table(name = "medicos")
@PrimaryKeyJoinColumn(name = "usuario_id")
public class Medico extends Usuario {

    private String especialidad;

    @OneToMany(mappedBy = "medico", cascade = CascadeType.ALL)
    private List<Turno> turnos = new ArrayList<>();

    public Medico() {}

    public Medico(String nombre, String usuario, String contrasena, String especialidad) {
        super(nombre, usuario, contrasena);
        this.especialidad = especialidad;
    }

    public String getEspecialidad() { return especialidad; }
    public void setEspecialidad(String especialidad) { this.especialidad = especialidad; }

    public List<Turno> getTurnos() { return turnos; }
    public void setTurnos(List<Turno> turnos) { this.turnos = turnos; }

    @Override
    public String toString() {
        return "Medico{" +
                "id=" + getId() +
                ", nombre='" + getNombre() + '\'' +
                ", usuario='" + getUsuario() + '\'' +
                ", especialidad='" + especialidad + '\'' +
                '}';
    }
}
