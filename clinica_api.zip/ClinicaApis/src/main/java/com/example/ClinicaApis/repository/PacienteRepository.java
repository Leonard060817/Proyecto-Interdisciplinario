package com.example.ClinicaApis.repository;

import com.example.ClinicaApis.model.Paciente;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;
import java.util.List;

@Repository
public interface PacienteRepository extends JpaRepository<Paciente, Long> {

    Optional<Paciente> findByDni(String dni);

    List<Paciente> findByApellidoContainingIgnoreCase(String apellido);

    Optional<Paciente> findByEmail(String email);
}
