package pruebaCodigo.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import pruebaCodigo.Medico;

public interface MedicoRepository extends JpaRepository<Medico, Long> {
}
