package pruebaCodigo.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import pruebaCodigo.Turno;

public interface TurnoRepository extends JpaRepository<Turno, Long> {
}
