package pruebaCodigo.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import pruebaCodigo.Diagnostico;

public interface DiagnosticoRepository extends JpaRepository<Diagnostico, Long> {
}
