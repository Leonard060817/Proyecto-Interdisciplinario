package com.clinica.ClinicaAPI.service;

import java.util.List;
import java.util.Optional;
import org.springframework.stereotype.Service;
import com.clinica.ClinicaAPI.model.Paciente;
import com.clinica.ClinicaAPI.repository.PacienteRepository;

@Service
public class PacienteService {
    private final PacienteRepository repo;

    public PacienteService(PacienteRepository repo) {
        this.repo = repo;
    }

    public List<Paciente> listar() {
        return repo.findAll();
    }

    public Optional<Paciente> buscarPorId(Long id) {
        return repo.findById(id);
    }

    public Paciente guardar(Paciente p) {
        return repo.save(p);
    }

    public void eliminar(Long id) {
        repo.deleteById(id);
    }
}
