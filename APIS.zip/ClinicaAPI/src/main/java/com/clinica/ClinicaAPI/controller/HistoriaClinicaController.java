package com.clinica.ClinicaAPI.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.web.bind.annotation.*;
import com.clinica.ClinicaAPI.model.HistoriaClinica;
import com.clinica.ClinicaAPI.service.HistoriaClinicaService;

@RestController
@RequestMapping("/api/historias")
public class HistoriaClinicaController {

    private final HistoriaClinicaService service;

    public HistoriaClinicaController(HistoriaClinicaService service) {
        this.service = service;
    }

    @GetMapping
    public List<HistoriaClinica> listar() {
        return service.listar();
    }

    @GetMapping("/{id}")
    public Optional<HistoriaClinica> obtener(@PathVariable Long id) {
        return service.buscarPorId(id);
    }

    @PostMapping
    public HistoriaClinica crear(@RequestBody HistoriaClinica h) {
        return service.guardar(h);
    }

    @PutMapping("/{id}")
    public HistoriaClinica actualizar(@PathVariable Long id, @RequestBody HistoriaClinica h) {
        h.setId(id);
        return service.guardar(h);
    }

    @DeleteMapping("/{id}")
    public void eliminar(@PathVariable Long id) {
        service.eliminar(id);
    }
}
