package com.clinica.ClinicaAPI.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.web.bind.annotation.*;
import com.clinica.ClinicaAPI.model.Diagnostico;
import com.clinica.ClinicaAPI.service.DiagnosticoService;

@RestController
@RequestMapping("/api/diagnosticos")
public class DiagnosticoController {

    private final DiagnosticoService service;

    public DiagnosticoController(DiagnosticoService service) {
        this.service = service;
    }

    @GetMapping
    public List<Diagnostico> listar() {
        return service.listar();
    }

    @GetMapping("/{id}")
    public Optional<Diagnostico> obtener(@PathVariable Long id) {
        return service.buscarPorId(id);
    }

    @PostMapping
    public Diagnostico crear(@RequestBody Diagnostico d) {
        return service.guardar(d);
    }

    @PutMapping("/{id}")
    public Diagnostico actualizar(@PathVariable Long id, @RequestBody Diagnostico d) {
        d.setId(id);
        return service.guardar(d);
    }

    @DeleteMapping("/{id}")
    public void eliminar(@PathVariable Long id) {
        service.eliminar(id);
    }
}
