package com.clinica.ClinicaAPI.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.web.bind.annotation.*;
import com.clinica.ClinicaAPI.model.Turno;
import com.clinica.ClinicaAPI.service.TurnoService;

@RestController
@RequestMapping("/api/turnos")
public class TurnoController {

    private final TurnoService service;

    public TurnoController(TurnoService service) {
        this.service = service;
    }

    @GetMapping
    public List<Turno> listar() {
        return service.listar();
    }

    @GetMapping("/{id}")
    public Optional<Turno> obtener(@PathVariable Long id) {
        return service.buscarPorId(id);
    }

    @PostMapping
    public Turno crear(@RequestBody Turno t) {
        return service.guardar(t);
    }

    @PutMapping("/{id}")
    public Turno actualizar(@PathVariable Long id, @RequestBody Turno t) {
        t.setId(id);
        return service.guardar(t);
    }

    @DeleteMapping("/{id}")
    public void eliminar(@PathVariable Long id) {
        service.eliminar(id);
    }
}
