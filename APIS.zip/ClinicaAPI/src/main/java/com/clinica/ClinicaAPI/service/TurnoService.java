package com.clinica.ClinicaAPI.service;

import java.util.List;
import java.util.Optional;
import org.springframework.stereotype.Service;
import com.clinica.ClinicaAPI.model.Turno;
import com.clinica.ClinicaAPI.repository.TurnoRepository;

@Service
public class TurnoService {
    private final TurnoRepository repo;

    public TurnoService(TurnoRepository repo) {
        this.repo = repo;
    }

    public List<Turno> listar() {
        return repo.findAll();
    }

    public Optional<Turno> buscarPorId(Long id) {
        return repo.findById(id);
    }

    public Turno guardar(Turno t) {
        return repo.save(t);
    }

    public void eliminar(Long id) {
        repo.deleteById(id);
    }
}
