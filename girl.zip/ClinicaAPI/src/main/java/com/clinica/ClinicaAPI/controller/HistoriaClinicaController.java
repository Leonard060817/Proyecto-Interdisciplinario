package com.clinica.ClinicaAPI.controller;

import com.clinica.ClinicaAPI.model.HistoriaClinica;
import com.clinica.ClinicaAPI.service.HistoriaClinicaService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/historias")
public class HistoriaClinicaController {

    private final HistoriaClinicaService service;

    public HistoriaClinicaController(HistoriaClinicaService service) {
        this.service = service;
    }

    @GetMapping
    public List<HistoriaClinica> listar() { return service.listar(); }

    @PostMapping
    public HistoriaClinica guardar(@RequestBody HistoriaClinica h) { return service.guardar(h); }

    @GetMapping("/{id}")
    public HistoriaClinica obtener(@PathVariable Long id) { return service.buscar(id); }

    @DeleteMapping("/{id}")
    public void eliminar(@PathVariable Long id) { service.eliminar(id); }
}
