package com.clinica.ClinicaAPI.service;

import com.clinica.ClinicaAPI.model.Turno;
import com.clinica.ClinicaAPI.repository.TurnoRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class TurnoService {

    private final TurnoRepository repo;

    public TurnoService(TurnoRepository repo) {
        this.repo = repo;
    }

    public List<Turno> listar() { return repo.findAll(); }

    public Turno guardar(Turno t) { return repo.save(t); }

    public Turno buscar(Long id) { return repo.findById(id).orElse(null); }

    public void eliminar(Long id) { repo.deleteById(id); }
}
