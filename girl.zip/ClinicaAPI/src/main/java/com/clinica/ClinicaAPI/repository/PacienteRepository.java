package com.clinica.ClinicaAPI.repository;

import com.clinica.ClinicaAPI.model.Paciente;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PacienteRepository extends JpaRepository<Paciente, Long> {
}
