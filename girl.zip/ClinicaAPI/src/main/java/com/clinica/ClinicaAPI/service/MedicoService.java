package com.clinica.ClinicaAPI.service;

import com.clinica.ClinicaAPI.model.Medico;
import com.clinica.ClinicaAPI.repository.MedicoRepository;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class MedicoService {

    private final MedicoRepository repo;

    public MedicoService(MedicoRepository repo) {
        this.repo = repo;
    }

    public List<Medico> listar() { return repo.findAll(); }

    public Medico guardar(Medico m) { return repo.save(m); }

    public Medico buscar(Long id) { return repo.findById(id).orElse(null); }

    public void eliminar(Long id) { repo.deleteById(id); }
}
