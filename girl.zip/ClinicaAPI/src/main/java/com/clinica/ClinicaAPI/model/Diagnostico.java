package com.clinica.ClinicaAPI.model;

import jakarta.persistence.*;
import java.time.LocalDate;

@Entity
@Table(name = "diagnosticos")
public class Diagnostico {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private LocalDate fecha;
    private String texto;

    @ManyToOne
    @JoinColumn(name = "medico_id")
    private Medico medico;

    @ManyToOne
    @JoinColumn(name = "historia_id")
    private HistoriaClinica historiaClinica;

    public Diagnostico() {}

    public Diagnostico(String texto, Medico medico, HistoriaClinica historia) {
        this.fecha = LocalDate.now();
        this.texto = texto;
        this.medico = medico;
        this.historiaClinica = historia;
    }

    public Long getId() { return id; }
}
