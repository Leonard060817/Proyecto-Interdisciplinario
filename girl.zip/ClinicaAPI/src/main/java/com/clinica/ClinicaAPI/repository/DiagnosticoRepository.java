package com.clinica.ClinicaAPI.repository;

import com.clinica.ClinicaAPI.model.Diagnostico;
import org.springframework.data.jpa.repository.JpaRepository;

public interface DiagnosticoRepository extends JpaRepository<Diagnostico, Long> {}
