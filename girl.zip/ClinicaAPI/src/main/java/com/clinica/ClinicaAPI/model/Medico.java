package com.clinica.ClinicaAPI.model;

import jakarta.persistence.*;
import java.util.*;

@Entity
@Table(name = "medicos")
@PrimaryKeyJoinColumn(name = "usuario_id")
public class Medico extends Usuario {

    private String especialidad;

    @OneToMany(mappedBy = "medico", cascade = CascadeType.ALL)
    private List<Turno> turnos = new ArrayList<>();

    public Medico() {}

    public Medico(String nombre, String usuario, String contrasena, String especialidad) {
        super(nombre, usuario, contrasena);
        this.especialidad = especialidad;
    }

    public String getEspecialidad() { return especialidad; }
    public void setEspecialidad(String especialidad) { this.especialidad = especialidad; }

    public List<Turno> getTurnos() { return turnos; }
}
