package com.clinica.ClinicaAPI.service;

import com.clinica.ClinicaAPI.model.HistoriaClinica;
import com.clinica.ClinicaAPI.repository.HistoriaClinicaRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class HistoriaClinicaService {

    private final HistoriaClinicaRepository repo;

    public HistoriaClinicaService(HistoriaClinicaRepository repo) {
        this.repo = repo;
    }

    public List<HistoriaClinica> listar() { return repo.findAll(); }

    public HistoriaClinica guardar(HistoriaClinica h) { return repo.save(h); }

    public HistoriaClinica buscar(Long id) { return repo.findById(id).orElse(null); }

    public void eliminar(Long id) { repo.deleteById(id); }
}
