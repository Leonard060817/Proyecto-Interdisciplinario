package com.clinica.ClinicaAPI.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.clinica.ClinicaAPI.model.Usuario;
import com.clinica.ClinicaAPI.repository.UsuarioRepository;

@Service
public class UsuarioService {

    @Autowired
    private UsuarioRepository usuarioRepository;

    public boolean validarAcceso(String usuario, String contrasena) {

        Usuario user = usuarioRepository.findByUsuario(usuario);

        if (user == null) return false;

        return user.getContrasena().equals(contrasena);
    }
}
