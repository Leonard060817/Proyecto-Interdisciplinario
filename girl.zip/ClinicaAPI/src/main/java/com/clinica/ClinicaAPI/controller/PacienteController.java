package com.clinica.ClinicaAPI.controller;

import com.clinica.ClinicaAPI.model.Paciente;
import com.clinica.ClinicaAPI.service.PacienteService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/pacientes")
public class PacienteController {

    private final PacienteService service;

    public PacienteController(PacienteService service) {
        this.service = service;
    }

    @GetMapping
    public List<Paciente> listar() { return service.listar(); }

    @PostMapping
    public Paciente guardar(@RequestBody Paciente p) { return service.guardar(p); }

    @GetMapping("/{id}")
    public Paciente obtener(@PathVariable Long id) { return service.buscar(id); }

    @DeleteMapping("/{id}")
    public void eliminar(@PathVariable Long id) { service.eliminar(id); }
}
