package com.clinica.ClinicaAPI.controller;

import com.clinica.ClinicaAPI.model.Diagnostico;
import com.clinica.ClinicaAPI.service.DiagnosticoService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/diagnosticos")
public class DiagnosticoController {

    private final DiagnosticoService service;

    public DiagnosticoController(DiagnosticoService service) {
        this.service = service;
    }

    @GetMapping
    public List<Diagnostico> listar() { return service.listar(); }

    @PostMapping
    public Diagnostico guardar(@RequestBody Diagnostico d) { return service.guardar(d); }

    @GetMapping("/{id}")
    public Diagnostico obtener(@PathVariable Long id) { return service.buscar(id); }

    @DeleteMapping("/{id}")
    public void eliminar(@PathVariable Long id) { service.eliminar(id); }
}
