package com.example.ClinicaApis.repository;

import com.clinica.ClinicaApis.model.HistoriaClinica;
import org.springframework.data.jpa.repository.JpaRepository;

public interface HistoriaClinicaRepository extends JpaRepository<HistoriaClinica, Long> {}
