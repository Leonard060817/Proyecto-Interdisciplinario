package com.example.ClinicaApis.controller;

import com.clinica.ClinicaApis.model.Turno;
import com.clinica.ClinicaApis.service.TurnoService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/turnos")
public class TurnoController {

    private final TurnoService service;

    public TurnoController(TurnoService service) {
        this.service = service;
    }

    @GetMapping
    public List<Turno> listar() { return service.listar(); }

    @PostMapping
    public Turno guardar(@RequestBody Turno t) { return service.guardar(t); }

    @GetMapping("/{id}")
    public Turno obtener(@PathVariable Long id) { return service.buscar(id); }

    @DeleteMapping("/{id}")
    public void eliminar(@PathVariable Long id) { service.eliminar(id); }
}
