package com.example.ClinicaApis.repository;

import com.clinica.ClinicaApis.model.Turno;
import org.springframework.data.jpa.repository.JpaRepository;

public interface TurnoRepository extends JpaRepository<Turno, Long> {}

