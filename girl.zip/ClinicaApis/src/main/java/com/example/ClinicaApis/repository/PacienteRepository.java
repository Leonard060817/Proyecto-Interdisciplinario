package com.example.ClinicaApis.repository;

import com.clinica.ClinicaApis.model.Paciente;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PacienteRepository extends JpaRepository<Paciente, Long> {
}
