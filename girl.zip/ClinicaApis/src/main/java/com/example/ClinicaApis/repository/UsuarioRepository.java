package com.example.ClinicaApis.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.clinica.ClinicaApis.model.Usuario;

public interface UsuarioRepository extends JpaRepository<Usuario, Long> {
    Usuario findByUsuario(String usuario);
}
