package com.example.ClinicaApis.repository;

import com.clinica.ClinicaApis.model.Diagnostico;
import org.springframework.data.jpa.repository.JpaRepository;

public interface DiagnosticoRepository extends JpaRepository<Diagnostico, Long> {}