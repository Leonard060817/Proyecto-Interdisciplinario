package com.example.ClinicaApis.controller;

import com.clinica.ClinicaApis.model.Medico;
import com.clinica.ClinicaApis.service.MedicoService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/medicos")
public class MedicoController {

    private final MedicoService service;

    public MedicoController(MedicoService service) {
        this.service = service;
    }

    @GetMapping
    public List<Medico> listar() { return service.listar(); }

    @PostMapping
    public Medico guardar(@RequestBody Medico m) { return service.guardar(m); }

    @GetMapping("/{id}")
    public Medico obtener(@PathVariable Long id) { return service.buscar(id); }

    @DeleteMapping("/{id}")
    public void eliminar(@PathVariable Long id) { service.eliminar(id); }
}
