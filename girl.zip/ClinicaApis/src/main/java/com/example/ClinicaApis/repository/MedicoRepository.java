package com.example.ClinicaApis.repository;

import com.clinica.ClinicaApis.model.Medico;
import org.springframework.data.jpa.repository.JpaRepository;

public interface MedicoRepository extends JpaRepository<Medico, Long> {}
