package com.example.ClinicaApis.service;

import com.clinica.ClinicaApis.model.Diagnostico;
import com.clinica.ClinicaApis.repository.DiagnosticoRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class DiagnosticoService {

    private final DiagnosticoRepository repo;

    public DiagnosticoService(DiagnosticoRepository repo) {
        this.repo = repo;
    }

    public List<Diagnostico> listar() { return repo.findAll(); }

    public Diagnostico guardar(Diagnostico d) { return repo.save(d); }

    public Diagnostico buscar(Long id) { return repo.findById(id).orElse(null); }

    public void eliminar(Long id) { repo.deleteById(id); }
}
