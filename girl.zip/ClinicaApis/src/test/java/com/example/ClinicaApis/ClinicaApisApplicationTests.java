package com.example.ClinicaApis;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ClinicaApisApplicationTests {

	@Test
	void contextLoads() {
	}

}
